<!--EQS
date:2092019
owner:chriss ngure
id:dickson john
signature:xon
copyright 2019

-->


<html>
<?php include'header.php'; ?>





<!--story div here -->
<div class="row mt-3" style="">
<div class="container col-md-10 mr  ">
    <div class="img col-md-3 "  style="float: left;"><img src="pic/40.jpg" class="img-fluid"></div>
    <div class="desc col-md-9" style="float: left;">
     <span class="h5 text-info">Go make papa proud</span><br>
    my storyWhen working on an image in Photoshop you must first properly size the image, depending on the
    media discipline you are using. This is specifically important due to images varying for Web and
    Print use. Larger images on a website will actually slow the site down, making it difficult for your
    viewer to see the content.</div>

    <div class="opt  col-md-9 mt-3 bg-light" style="float: left;">
    <span><a href="episodes.php" class="btn btn-light btn-hovered btn-sm text-primary"> Read More...</a></span>
    <span class="text-right" style="float:right;">
         <span class="small text-info btn btn-sm btn-light">&nbsp;<a href=""><i class="fa fa-user-circle-o text-info"></i> xon </a></span>&nbsp;
        &nbsp; <i class="fa fa-thumbs-up text-success"></i> 20
        &nbsp; <i class="fa fa-comments text-info"></i> 100

    </span> 
    </div> </div><!-- stories box--> 
     <hr class="col-md-10"></div>

 



<!--story div here -->
<div class="row mt-3" style="">
<div class="container col-md-10 mr  ">
    <div class="img col-md-3 "  style="float: left;"><img src="pic/39.jpg" class="img-fluid"></div>
    <div class="desc col-md-9" style="float: left;">
     <span class="h5 text-info">MY Kudrat favourites</span><br>
    my storyWhen working on an image in Photoshop you must first properly size the image, depending on the
    media discipline you are using. This is specifically important due to images varying for Web and
    Print use. Larger images on a website will actually slow the site down, making it difficult for your
    viewer to see the content.</div>

    <div class="opt  col-md-9 mt-3 bg-light" style="float: left;">
    <span><a href="episodes.php" class="btn btn-light btn-hovered btn-sm text-primary"> Read More...</a></span>
    <span class="text-right" style="float:right;">
         <span class="small text-info btn btn-sm btn-light">&nbsp;<a href=""><i class="fa fa-user-circle-o text-info"></i> xon </a></span>&nbsp;
        &nbsp; <i class="fa fa-thumbs-up text-success"></i> 20
        &nbsp; <i class="fa fa-comments text-info"></i> 100

    </span> 
    </div> </div><!-- stories box--> 
 <hr class="col-md-10">
</div>


    
  
    
   

  


    
    



    
   
    
     
     

<script type="text/javascript">
$(document).ready(function(){
$("#omenu").click(function(){
$("#menu").toggle(1000);

});


});


</script>











 
<!-- 
 <div class="row col-md-12 pt-5" style="float:left; margin-top:100%;position:fixed;">
 <div class="container col-md-12 text-center text-info">
 EQS&copy;2019
 
 
 
 </div></div>-->
 
         
   
         </body>
         </html>
 





